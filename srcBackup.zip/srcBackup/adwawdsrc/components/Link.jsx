import React from 'react'; export const Link = ({ to, children }) => <a href={to}>{children}</a>;
