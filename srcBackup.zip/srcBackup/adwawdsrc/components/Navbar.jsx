import React from 'react'; export const Navbar = () => <nav>Navbar</nav>;
