import { useEffect } from 'react'; export const useEffectOnce = (fn) => useEffect(fn, []);
