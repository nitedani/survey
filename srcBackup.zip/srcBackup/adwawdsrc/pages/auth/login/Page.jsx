import React from 'react'; const Login = () => <div>Login Page</div>; export default Login;
