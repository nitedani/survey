import React from 'react'; const Signup = () => <div>Signup Page</div>; export default Signup;
