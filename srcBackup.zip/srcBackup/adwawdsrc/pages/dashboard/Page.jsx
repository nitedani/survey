import React from 'react'; const Dashboard = () => <div>Dashboard</div>; export default Dashboard;
