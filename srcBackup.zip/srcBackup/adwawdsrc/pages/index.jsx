import React from 'react'; const HomePage = () => <div>Welcome to the Homepage</div>; export default HomePage;
