import fs from 'fs';
import path from 'path';

const loadConfig = () => {
    const env = process.env.NODE_ENV || 'development';
    const configPath = path.resolve('config.json');
    const config = JSON.parse(fs.readFileSync(configPath, 'utf-8'));

    return config[env];
};

export default loadConfig;
