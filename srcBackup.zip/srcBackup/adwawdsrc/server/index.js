import express from 'express';
import dotenv from 'dotenv';
import loadConfig from './config.js';
import { renderPage } from 'vike/server';
import supabaseMiddleware from './middlewares/supabaseMiddleware.js';
import sessionUserMiddleware from './middlewares/sessionUserMiddleware.js';

// Load environment variables from .env file
dotenv.config();

// Load configuration
const config = loadConfig();
const port = config.port || process.env.PORT || 3000;

const app = express();

// Use middleware
app.use(supabaseMiddleware);
app.use(sessionUserMiddleware);

// Serve static files from the public directory
app.use(express.static('public'));

// Define API routes
app.get('/api/data', (req, res) => {
    res.json({ message: 'This is your data.' });
});

// Handle all other routes with SSR
app.get('*', async (req, res, next) => {
    try {
        const pageContextInit = {
            urlOriginal: req.originalUrl,
            headersOriginal: req.headers,
            req,
            user: req.user,
            session: req.session,
            supabase: req.supabase,
        };

        const pageContext = await renderPage(pageContextInit);
        const { httpResponse } = pageContext;
        if (!httpResponse) {
            return next();
        } else {
            const { statusCode, headers, earlyHints } = httpResponse;
            headers.forEach(([name, value]) => res.setHeader(name, value));
            res.status(statusCode);
            httpResponse.pipe(res);
        }
    } catch (error) {
        next(error);
    }
});

// Error handling middleware
app.use((err, req, res, next) => {
    console.error(err);
    res.status(500).send('Internal Server Error');
});

// Start server
app.listen(port, () => {
    console.log(`Server running on port ${port}`);
});
