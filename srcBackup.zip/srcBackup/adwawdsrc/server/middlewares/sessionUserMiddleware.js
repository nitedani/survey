// src/server/middlewares/sessionUserMiddleware.js
const sessionUserMiddleware = async (req, res, next) => {
    const fetchUserSession = async (req) => {
        // Implement the logic to fetch user session
        return { session: {}, user: {} };
    };

    const { session, user } = await fetchUserSession(req);
    req.session = session;
    req.user = user;
    next();
};

module.exports = sessionUserMiddleware;
