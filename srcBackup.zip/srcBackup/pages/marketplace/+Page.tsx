export default function Page() {
  return 'ok'
}
